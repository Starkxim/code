print('enter smaller num')
a=float(input())
print('enter bigger num')
b=float(input())
c=(3**0.5)*(b-a)
d=(a+b)*c/2
print('answer is',d)
