import math
math.pi
print('enter r')
r=float(input())
print('enter n')
n=int(input())
a=math.tan(math.pi/n)*r*2
print('s is',r*n*a/2)
print('p is',a*n)
