print('enter a')
a=int(input())
x=a//1000
y=(a%1000)//100
z=(a%100)//10
w=a%10
print(x,y,z,w)
