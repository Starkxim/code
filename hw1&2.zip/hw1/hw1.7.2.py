print('enter a')
a=int(input())
x=a//10000
y=(a%10000)//1000
z=(a%1000)//100
v=(a%100)//10
w=a%10
print(x,y,z,v,w)
