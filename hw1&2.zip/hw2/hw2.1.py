print('enter x1,x2,x3')
a=float(input())
b=float(input())
c=float(input())
d=-(a+b+c)
e=a*b+a*c+b*c
f=-a*b*c
print(d,e,f)
