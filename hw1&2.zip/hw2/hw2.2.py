print('enter p')
p=float(input())
mm=p*1000
ri=mm/44.45
rr=ri/16
ra=rr/3
rk=ra/500
print(mm,'mm',ri,'ri',rr,'rr',ra,'ra',rk,'rk')
