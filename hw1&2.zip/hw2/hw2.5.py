print('n=')
n=int(input())
a=n//4
b=n%4
print('b',b,'a',a,)
