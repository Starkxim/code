print('enter a')
a=float(input())
b=a/100
c=a/10
d=a/3
e=a/0.25
print(b,'rub',c,'gri',d,'ars',e,'pol')
