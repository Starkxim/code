a=int(input("a="))
if a>=25 and a<=50:
    print("Подходит")
else:
    print("не Подходит")
