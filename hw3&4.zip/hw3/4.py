a=int(input("a="))
if(a//10<10 and a//10>0):
    print("да")
else:
    print("не Подходит")
