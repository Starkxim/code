a=int(input("a="))
if(a//1000==a%10 and a%1000//100==a%100//10):
    print("да")
else:
    print("не Подходит")
