time=int(input('enter time='))
print(2**(time/3))
