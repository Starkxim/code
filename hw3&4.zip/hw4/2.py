a=float(input('enter a real num='))
n=int(input('enter a interger='))
b=1
for i in range (n):
    b*=a
print(b)
