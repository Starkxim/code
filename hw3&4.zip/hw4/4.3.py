a=1
i=1
n=2
while i<9999:
    i=i+2
    a+=1/i
while n<10000:
    n=n+2
    a-=1/i
print(a)
