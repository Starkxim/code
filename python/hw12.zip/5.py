def writerandom():
    import random
    nf = open('numbers.txt.', 'w+')
    n = int(input('number of random='))
    a = 0
    sum = 0
    for i in range(n):
        a = random.randint(1, 500)
        sum += a
        nf.write(str(a) + '\n')
    print(sum, sum / n)
    nf.close()
writerandom()